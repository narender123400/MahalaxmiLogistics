import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stock-tab',
  templateUrl: './stock-tab.component.html'
})
export class StockTabComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
