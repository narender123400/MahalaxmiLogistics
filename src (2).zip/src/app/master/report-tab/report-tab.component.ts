import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-tab',
  templateUrl: './report-tab.component.html'
})
export class ReportTabComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
